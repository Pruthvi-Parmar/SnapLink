export const dummyData = [
    {
      id: 1,
      clickDate: "2024-07-03",
      count: 35,
    },
    {
      id: 2,
      clickDate: "2024-07-04",
      count: 70,
    },
    {
      id: 3,
      clickDate: "2024-07-05",
      count: 25,
    },
    {
      id: 4,
      clickDate: "2024-07-06",
      count: 110,
    },
    {
      id: 5,
      clickDate: "2024-07-07",
      count: 170,
    },
    {
      id: 6,
      clickDate: "2024-07-08",
      count: 225,
    },
    {
      id: 7,
      clickDate: "2024-07-09",
      count: 115,
    },
    {
      id: 8,
      clickDate: "2024-07-10",
      count: 70,
    },
    {
      id: 9,
      clickDate: "2024-07-11",
      count: 300,
    },
    {
      id: 10,
      clickDate: "2024-07-12",
      count: 80,
    },
    {
      id: 11,
      clickDate: "2024-07-13",
      count: 100,
    },
    {
      id: 12,
      clickDate: "2024-07-14",
      count: 160,
    },
    {
      id: 13,
      clickDate: "2024-07-15",
      count: 210,
    },
    {
      id: 14,
      clickDate: "2024-07-16",
      count: 50,
    },
    {
      id: 15,
      clickDate: "2024-07-17",
      count: 261,
    },
    {
      id: 16,
      clickDate: "2024-07-18",
      count: 20,
    },
    {
      id: 17,
      clickDate: "2024-07-19",
      count: 60,
    },
    {
      id: 18,
      clickDate: "2024-07-20",
      count: 35,
    },
    {
      id: 19,
      clickDate: "2024-07-21",
      count: 45,
    },
    {
      id: 20,
      clickDate: "2024-07-22",
      count: 60,
    },
    {
      id: 21,
      clickDate: "2024-07-23",
      count: 65,
    },
    {
      id: 22,
      clickDate: "2024-07-24",
      count: 75,
    },
    {
      id: 23,
      clickDate: "2024-07-25",
      count: 150,
    },
    {
      id: 24,
      clickDate: "2024-07-26",
      count: 180,
    },
    {
      id: 25,
      clickDate: "2024-07-27",
      count: 200,
    },
    {
      id: 26,
      clickDate: "2024-07-28",
      count: 110,
    },
    {
      id: 27,
      clickDate: "2024-07-29",
      count: 190,
    },
    {
      id: 28,
      clickDate: "2024-07-30",
      count: 195,
    },
    {
      id: 29,
      clickDate: "2024-07-31",
      count: 220,
    },
    {
      id: 30,
      clickDate: "2024-08-01",
      count: 105,
    },
  ];
  
  export const lessDummyData = [
    {
      id: 1,
      clickDate: "2024-07-01",
      count: 17,
    },
    {
      id: 2,
      clickDate: "2024-07-02",
      count: 150,
    },
    {
      id: 3,
      clickDate: "2024-07-03",
      count: 95,
    },
    {
      id: 4,
      clickDate: "2024-07-04",
      count: 120,
    },
    {
      id: 5,
      clickDate: "2024-07-07",
      count: 240,
    },
    {
      id: 6,
      clickDate: "2024-07-08",
      count: 300,
    },
    {
      id: 7,
      clickDate: "2024-07-09",
      count: 220,
    },
    {
      id: 8,
      clickDate: "2024-07-10",
      count: 50,
    },
    {
      id: 9,
      clickDate: "2024-07-11",
      count: 80,
    },
    {
      id: 10,
      clickDate: "2024-07-12",
      count: 110,
    },
    {
      id: 11,
      clickDate: "2024-07-13",
      count: 165,
    },
    {
      id: 12,
      clickDate: "2024-07-14",
      count: 111,
    },
    {
      id: 13,
      clickDate: "2024-07-15",
      count: 77,
    },
    {
      id: 14,
      clickDate: "2024-07-16",
      count: 200,
    },
    {
      id: 15,
      clickDate: "2024-07-17",
      count: 100,
    },
    {
      id: 16,
      clickDate: "2024-07-18",
      count: 240,
    },
    {
      id: 17,
      clickDate: "2024-07-19",
      count: 270,
    },
    {
      id: 18,
      clickDate: "2024-07-20",
      count: 170,
    },
    {
      id: 19,
      clickDate: "2024-07-21",
      count: 60,
    },
    {
      id: 20,
      clickDate: "2024-07-22",
      count: 235,
    },
  ];